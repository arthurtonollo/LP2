﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxFilmes.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        { 
            double[,] notas = new double[2,2];
            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 2; j++)
                    
                {
                    string notaFilmes = Microsoft.VisualBasic.Interaction.InputBox($"Pessoa {j + 1} Digite a nota do filme {i + 1}:", "Entrada de Dados");
                    notas[i, j] = Convert.ToDouble(notaFilmes);
                    if (notas[i,j] < 0 || notas[i,j] > 10) 
                    {
                        MessageBox.Show("Entrada de dados inválido!");
                    }
                    else
                    {
                        lstboxFilmes.Items.Add($"Pessoa: 1 Nota do Filme 1: {notas[0, 0]} Nota do Filme 2: {notas[1, 1]}");
                        lstboxFilmes.Items.Add($"Pessoa: 2 Nota do Filme 1: {notas[0, 0]} Nota do Filme 2: {notas[1, 1]}");
                        lstboxFilmes.Items.Add($"Média do filme 1:{(notas[0, 0] + notas[1, 0]) / 2}");
                        lstboxFilmes.Items.Add($"Média do filme 1:{(notas[1, 1] + notas[1, 1]) / 2}");
                    }
                }
            }
        }
    }

