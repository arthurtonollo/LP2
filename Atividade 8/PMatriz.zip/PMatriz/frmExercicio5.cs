﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[] gabarito = { 'A', 'C', 'D', 'B', 'E', 'A', 'C', 'D', 'B', 'E' };
            char[] respostasAluno = new char[10];
            int pontuacao = 0;
            for (int i = 0; i < 10; i++)
            {
                string input;
                bool entradaValida = false;
                do
                {
                    input = Microsoft.VisualBasic.Interaction.InputBox($"Resposta para a questão {i + 1} (A, B, C, D ou E):", "Entrada de Resposta");
                    char primeiraLetra = input.ToUpper().ToCharArray().FirstOrDefault();
                    if (new char[] { 'A', 'B', 'C', 'D', 'E' }.Contains(primeiraLetra))
                    {
                        respostasAluno[i] = primeiraLetra;
                        entradaValida = true;
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Entrada inválida. Use apenas A, B, C, D ou E (maiúsculas ou minúsculas).", "Erro de Entrada");
                    }
                } while (!entradaValida);
                if (respostasAluno[i] == gabarito[i])
                {
                    pontuacao++;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show($"Resposta da Questão {i + 1} Incorreta! O correto era {gabarito[i]}.", "Erro na Resposta");
                }
            }
            listBoxResultados.Items.Clear();
            listBoxResultados.Items.Add($"Pontuação Final: {pontuacao} de 10");
            listBoxResultados.Items.Add("--- Detalhes ---");
            for (int i = 0; i < 10; i++)
            {
                listBoxResultados.Items.Add($"Q{i + 1}: Status: {(respostasAluno[i] == gabarito[i] ? "Correta" : "Errada")}");
            }
        }
    }
}
