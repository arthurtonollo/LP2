﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            for (int i = 0; i < 10; i++)
            {
                string nomeCompleto = Microsoft.VisualBasic.Interaction.InputBox($"Digite o nome da pessoa {i + 1}:", "Entrada de Nome");
                nomes[i] = nomeCompleto.Replace(" ", "");
            }
            listBoxNomes.Items.Clear();
            foreach (string nome in nomes)
            {
                if (!string.IsNullOrWhiteSpace(nome))
                {
                    listBoxNomes.Items.Add($"o nome {nome} tem {nome.Length} caracteres");
                }
            }
        }

        private void listbox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
