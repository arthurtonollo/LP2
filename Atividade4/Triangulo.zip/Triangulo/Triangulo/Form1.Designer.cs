﻿namespace Triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVetorA = new System.Windows.Forms.Label();
            this.lblVetorB = new System.Windows.Forms.Label();
            this.lblVetorC = new System.Windows.Forms.Label();
            this.txtVetorA = new System.Windows.Forms.TextBox();
            this.txtVetorB = new System.Windows.Forms.TextBox();
            this.txtVetorC = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblVetorA
            // 
            this.lblVetorA.AutoSize = true;
            this.lblVetorA.Location = new System.Drawing.Point(148, 125);
            this.lblVetorA.Name = "lblVetorA";
            this.lblVetorA.Size = new System.Drawing.Size(63, 20);
            this.lblVetorA.TabIndex = 0;
            this.lblVetorA.Text = "Vetor A";
            this.lblVetorA.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVetorB
            // 
            this.lblVetorB.AutoSize = true;
            this.lblVetorB.Location = new System.Drawing.Point(148, 244);
            this.lblVetorB.Name = "lblVetorB";
            this.lblVetorB.Size = new System.Drawing.Size(63, 20);
            this.lblVetorB.TabIndex = 1;
            this.lblVetorB.Text = "Vetor B";
            // 
            // lblVetorC
            // 
            this.lblVetorC.AutoSize = true;
            this.lblVetorC.Location = new System.Drawing.Point(148, 357);
            this.lblVetorC.Name = "lblVetorC";
            this.lblVetorC.Size = new System.Drawing.Size(63, 20);
            this.lblVetorC.TabIndex = 2;
            this.lblVetorC.Text = "Vetor C";
            // 
            // txtVetorA
            // 
            this.txtVetorA.Location = new System.Drawing.Point(278, 125);
            this.txtVetorA.Name = "txtVetorA";
            this.txtVetorA.Size = new System.Drawing.Size(331, 26);
            this.txtVetorA.TabIndex = 3;
            this.txtVetorA.TextChanged += new System.EventHandler(this.txtVetorA_TextChanged);
            this.txtVetorA.Validated += new System.EventHandler(this.txtVetorA_Validated);
            // 
            // txtVetorB
            // 
            this.txtVetorB.Location = new System.Drawing.Point(278, 238);
            this.txtVetorB.Name = "txtVetorB";
            this.txtVetorB.Size = new System.Drawing.Size(331, 26);
            this.txtVetorB.TabIndex = 4;
            this.txtVetorB.Validated += new System.EventHandler(this.txtVetorB_Validated);
            // 
            // txtVetorC
            // 
            this.txtVetorC.Location = new System.Drawing.Point(278, 357);
            this.txtVetorC.Name = "txtVetorC";
            this.txtVetorC.Size = new System.Drawing.Size(331, 26);
            this.txtVetorC.TabIndex = 5;
            this.txtVetorC.Validated += new System.EventHandler(this.txtVetorC_Validated);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(278, 441);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(88, 38);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(390, 441);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(88, 38);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(521, 441);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(88, 38);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1787, 763);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtVetorC);
            this.Controls.Add(this.txtVetorB);
            this.Controls.Add(this.txtVetorA);
            this.Controls.Add(this.lblVetorC);
            this.Controls.Add(this.lblVetorB);
            this.Controls.Add(this.lblVetorA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVetorA;
        private System.Windows.Forms.Label lblVetorB;
        private System.Windows.Forms.Label lblVetorC;
        private System.Windows.Forms.TextBox txtVetorA;
        private System.Windows.Forms.TextBox txtVetorB;
        private System.Windows.Forms.TextBox txtVetorC;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

